package com.splitterorg.splitter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SplitterApplication {

  public static void main(String[] args) {
    SpringApplication.run(SplitterApplication.class, args);
  }

}
